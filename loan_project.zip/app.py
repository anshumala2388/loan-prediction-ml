from flask import Flask, render_template, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

app = Flask(__name__)

# Load dataset
data = pd.read_csv("loan_data.csv")

# Encode data
data['Gender'] = data['Gender'].map({'Male':1, 'Female':0})
data['Married'] = data['Married'].map({'Yes':1, 'No':0})
data['Education'] = data['Education'].map({'Graduate':1, 'Not Graduate':0})
data['Loan_Status'] = data['Loan_Status'].map({'Yes':1, 'No':0})

X = data[['Gender', 'Married', 'Education', 'Income', 'LoanAmount', 'Credit_History']]
y = data['Loan_Status']

# Train model
model = LogisticRegression()
model.fit(X, y)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        gender = int(request.form['gender'])
        married = int(request.form['married'])
        education = int(request.form['education'])
        income = float(request.form['income'])
        loan = float(request.form['loan'])
        credit = int(request.form['credit'])

        prediction = model.predict([[gender, married, education, income, loan, credit]])[0]
        result = "Approved" if prediction == 1 else "Rejected"

        return render_template("result.html", prediction=result)
    except:
        return "Error in input"

if __name__ == "__main__":
    app.run(debug=True)
